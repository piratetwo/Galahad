function [h_val,status] = quadratic_h(x)
 h_val(1) = 200;
 h_val(2) = 0;
 h_val(3) = 2;
 status = 0;
end

