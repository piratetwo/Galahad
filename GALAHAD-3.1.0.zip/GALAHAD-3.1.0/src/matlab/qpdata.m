DH = [ 2 1 ; 1 1 ] ; H = sparse(DH) ; g = [ 1 ; 2 ] ; f = 1.0 ;
DA = [ 2 1 ] ; A = sparse( DA) ; c_l= [-inf] ; c_u = [ 1.0 ]; 
x_l = [ 0 ; 0 ] ; x_u = [ inf ; inf ] ;
