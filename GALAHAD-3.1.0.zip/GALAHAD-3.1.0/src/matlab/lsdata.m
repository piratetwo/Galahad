DA = [ 2 1 ; 1 1 ] ; A = sparse(DA) ; 
b = [ 1 ; 2 ] ; B = [ 1 4 ; 2 4 ] ; 
control.lp=1 ;
