# CUTEst
The Constrained and Unconstrained Testing Environment with safe threads (CUTEst) for optimization software

[![Build Status](https://travis-ci.org/ralna/CUTEst.svg?branch=master)](https://travis-ci.org/ralna/CUTEst)

[![License: LGPL v3](https://img.shields.io/badge/License-LGPL%20v3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0)
