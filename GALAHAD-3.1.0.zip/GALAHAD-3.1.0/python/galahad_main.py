#!/usr/bin/python -uO

from galahad import *

#  Main program

if __name__ == '__main__':

    galahad = TkGalahad( )
    mainloop( )

#  function to display help



