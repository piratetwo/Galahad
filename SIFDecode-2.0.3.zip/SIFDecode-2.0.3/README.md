# SIFDecode
A package to decode SIF optimization test examples for use by CUTEst and GALAHAD

[![Build Status](https://travis-ci.org/ralna/SIFDecode.svg?branch=master)](https://travis-ci.org/ralna/SIFDecode)

[![License: LGPL v3](https://img.shields.io/badge/License-LGPL%20v3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0)
