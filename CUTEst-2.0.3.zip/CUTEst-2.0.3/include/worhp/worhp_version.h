#ifndef WORHP_VERSION_H
#define WORHP_VERSION_H

#ifndef WORHP_MAJOR
# define WORHP_MAJOR 1
#endif
#ifndef WORHP_MINOR
# define WORHP_MINOR 13
#endif
#ifndef WORHP_PATCH
# define WORHP_PATCH "0"
#endif
#ifndef WORHP_VERSION
# define WORHP_VERSION "1.13.0"
#endif

#endif
