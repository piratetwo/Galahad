# Digital/Compaq cc under Tru64

#
#  C compilation and loading
#

CC=cc
CCBASIC='-c -std1'
CCISO=''
CCDEBUG=#-DDEBUG_GALAHAD
CCFFLAGS=

CXX=c++
CXXBASIC='-c -std=c++11'
CXXOPT=-O2
CXXNOOPT=-O0
CXXDEBUG=''
CXXFFLAGS=''

HWLOC=''
