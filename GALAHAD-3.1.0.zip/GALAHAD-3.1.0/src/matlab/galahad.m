% GALAHAD -
%
%  Matlab interfaces to a number of GALAHAD optimization packages are
%  now available. See
%
%    help galahad_bqp
%    help galahad_bqpb
%    help galahad_cqp
%    help galahad_eqp
%    help galahad_glrt
%    help galahad_gltr
%    help galahad_lsqp
%    help galahad_lsrt
%    help galahad_lstr
%    help galahad_l2rt
%    help galahad_qpa
%    help galahad_qpb
%    help galahad_qpc
%    help galahad_rqs
%    help galahad_sbls
%    help galahad_sils
%    help galahad_trs
%    help galahad_wcp
%
% for further details
%
% GALAHAD productions 8/April/2010
