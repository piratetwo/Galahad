# GALAHAD
A library of modern Fortran modules for nonlinear optimization

[![License: LGPL v3](https://img.shields.io/badge/License-LGPL%20v3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0) 

